Hello how are you??
Where are you from??
Yes
Thank you my friend for the use of Edati
You will know yourself⁦^_^⁩
 ↓↓↓↓↓↓↓↓↓↓↓ ↓↓↓↓↓↓↓↓↓↓↓↓↓↓
────────────────────────────────────────
╔═╦═╗╔═╗╔══╗╔╦╗╔═╗╔═╦╗────╔╗╔╗╔══╗╔═╗╔╦╗
║║║║║║║║║══╣║╔╝║║║║║║║╔══╗║╚╝║║╔╗║║╔╝║╔╝
║║║║║║║║╠══║║╚╗║║║║║║║╚══╝║╔╗║║╠╣║║╚╗║╚╗
╚╩═╩╝╚═╝╚══╝╚╩╝╚═╝╚╩═╝────╚╝╚╝╚╝╚╝╚═╝╚╩╝
────────────────────────────────────────
# My Name: MOHAMMED SALEM
# Surname: MOSKON
# My Age: 17 Years old
# From: Yemen/Sana,a
# Skills: Programmer Bash+Python and Hacker
 ↓↓↓↓↓↓↓↓↓↓↓ ↓↓↓↓↓↓↓↓↓↓↓↓↓↓
 + YouTube:https://www.youtube.com/channel/UCrDpucyeuECBfVPXrdav6xw
 + Telegram:https://t.me/xomhg31
 + Whatsapp: +967715801806
 + Github: github.com/MOSKON-HACK
 ↓↓↓↓↓↓↓↓↓↓↓ ↓↓↓↓↓↓↓↓↓↓↓↓↓↓
 I see you later.......⁦:-)⁩